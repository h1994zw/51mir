/*******************************************************************************
*                 
*                 		       ���пƼ�
--------------------------------------------------------------------------------
* ʵ �� ��		 : RS232���ڷ�������
* ʵ��˵��       : ��Ƭ��һֱͨ�����ڷ��͡����пƼ����޹�˾��������
* ���ӷ�ʽ       : ������ͼ
* ע    ��		 : 
*******************************************************************************/


#include "clock.h"
#include "nokia_5110.h"
#include "bmp_pixel.h"
#include "stdio.h"
sbit key0=P1^0;
sbit key1=P1^1;
sbit key2=P1^6;
sbit key3=P1^7;
sbit bkenable=P2^5;
sbit alarm_en=P0^3;
sbit alarm_nn=P0^1;
//#ifndef 
//#include<reg51.h>
int time_a[8];
int my_number=0;
unsigned char flash=0;
int flag=6;
//unsigned int music[10];
unsigned char music_step=0;
//***********************************
#define	delay_time	25767
int MAX_DAY=30;


//--����ȫ�ֺ���--//
void UsartConfiguration();
void Delay10ms(unsigned int c);   //��� 0us
void inc_dec(unsigned flag_c);
void month_check()
{
	if(time_a[4]==1||time_a[4]==3||time_a[4]==5||time_a[4]==7||time_a[4]==8||time_a[4]==10||time_a[4]==12)
		MAX_DAY=31;
	else if(time_a[4]==2)
	{
		if(month%4)MAX_DAY=28;
		else MAX_DAY=29;
	}
	else MAX_DAY=30;
}
void exchange()
{
	time_a[0]=(int)hour;
	time_a[1]=(int)min;
	time_a[2]=(int)sec;
	time_a[3]=(int)date;
	time_a[4]=(int)month;
	time_a[5]=20;
	time_a[6]=(int)year;
	time_a[7]=(int)Dtemp;
}
void exchange_sec()
{
	time_a[2]=(int)sec;
}
/*******************************************************************************
* �� �� ��         : main
* ��������		   : ������
* ��    ��         : ��
* ��    ��         : ��
*******************************************************************************/
void show_time(char line)
{
	LCD_write_chinese_string(0,line,12,1,time_a[0]/10,0);
	LCD_write_chinese_string(8,line,12,1,time_a[0]%10,0);
	LCD_write_english_string(16,line,".");
	LCD_write_english_string(16,line+1,".");
	LCD_write_chinese_string(24,line,12,1,time_a[1]/10,0);
	LCD_write_chinese_string(32,line,12,1,time_a[1]%10,0);
	LCD_write_english_string(40,line,".");
	LCD_write_english_string(40,line+1,".");
	LCD_write_chinese_string(48,line,12,1,time_a[2]/10,0);
	LCD_write_chinese_string(56,line,12,1,time_a[2]%10,0);
}
void show_choose(char cho)
{
	char line=2;
	readsec();
	exchange_sec();
	if(cho==2||cho==3)cho++;
	else if(cho==4)cho=6;
	if(cho==0)
	{
		LCD_write_number(0,0,time_a[5]);
		LCD_write_number(12,0,time_a[6]);
		LCD_write_english_string(24,0,".");
		LCD_write_number(30,0,time_a[4]);
		LCD_write_english_string(42,0,".");
		LCD_write_number(48,0,time_a[3]);
		if(flash)
		{
			LCD_write_chinese_string(0,line,12,1,time_a[0]/10,0);
			LCD_write_chinese_string(8,line,12,1,time_a[0]%10,0);
		}
		else
		{
			LCD_write_chinese_string(0,line,12,1,10,0);
			LCD_write_chinese_string(8,line,12,1,10,0);
		}
		LCD_write_english_string(16,line,".");
		LCD_write_english_string(16,line+1,".");
		LCD_write_chinese_string(24,line,12,1,time_a[1]/10,0);
		LCD_write_chinese_string(32,line,12,1,time_a[1]%10,0);
		LCD_write_english_string(40,line,".");
		LCD_write_english_string(40,line+1,".");
		LCD_write_chinese_string(48,line,12,1,time_a[2]/10,0);
		LCD_write_chinese_string(56,line,12,1,time_a[2]%10,0);
		
		//LCD_write_chinese_string(48,line,12,1,time_a[7]/10,0);
		//LCD_write_chinese_string(56,line,12,1,time_a[7]%10,0);
	}

	else if(cho==1)
	{
		LCD_write_number(0,0,time_a[5]);
		LCD_write_number(12,0,time_a[6]);
		LCD_write_english_string(24,0,".");
		LCD_write_number(30,0,time_a[4]);
		LCD_write_english_string(42,0,".");
		LCD_write_number(48,0,time_a[3]);
		LCD_write_chinese_string(0,line,12,1,time_a[0]/10,0);
		LCD_write_chinese_string(8,line,12,1,time_a[0]%10,0);		
		LCD_write_english_string(16,line,".");
		LCD_write_english_string(16,line+1,".");
		if(flash)
		{
			LCD_write_chinese_string(24,line,12,1,time_a[1]/10,0);
			LCD_write_chinese_string(32,line,12,1,time_a[1]%10,0);
		}
		else
		{
			LCD_write_chinese_string(24,line,12,1,10,0);
			LCD_write_chinese_string(32,line,12,1,10,0);			
		}
		LCD_write_english_string(40,line,".");
		LCD_write_english_string(40,line+1,".");
		LCD_write_chinese_string(48,line,12,1,time_a[2]/10,0);
		LCD_write_chinese_string(56,line,12,1,time_a[2]%10,0);
	}
	else if(cho==3)//����
	{
		LCD_write_chinese_string(0,line,12,1,time_a[0]/10,0);
		LCD_write_chinese_string(8,line,12,1,time_a[0]%10,0);		
		LCD_write_english_string(16,line,".");
		LCD_write_english_string(16,line+1,".");
		LCD_write_chinese_string(24,line,12,1,time_a[1]/10,0);
		LCD_write_chinese_string(32,line,12,1,time_a[1]%10,0);
		LCD_write_number(0,0,time_a[5]);
		LCD_write_number(12,0,time_a[6]);
		LCD_write_english_string(24,0,".");
		LCD_write_number(30,0,time_a[4]);
		LCD_write_english_string(42,0,".");
		
		if(flash)
		{
			LCD_write_number(48,0,time_a[3]);			
		}
		else
		{
			LCD_write_english_string(48,0,"  ");
		}
		LCD_write_english_string(40,line,".");
		LCD_write_english_string(40,line+1,".");
		LCD_write_chinese_string(48,line,12,1,time_a[2]/10,0);
		LCD_write_chinese_string(56,line,12,1,time_a[2]%10,0);		
	}
	else if(cho==4)//�·�
	{
		LCD_write_number(0,0,time_a[5]);
		LCD_write_number(12,0,time_a[6]);
		LCD_write_english_string(24,0,".");

		LCD_write_english_string(42,0,".");
		LCD_write_number(48,0,time_a[3]);	
		LCD_write_chinese_string(0,line,12,1,time_a[0]/10,0);
		LCD_write_chinese_string(8,line,12,1,time_a[0]%10,0);		
		LCD_write_english_string(16,line,".");
		LCD_write_english_string(16,line+1,".");
		if(flash)
		{
			LCD_write_number(30,0,time_a[4]);			
		}
		else
		{
			LCD_write_english_string(30,0,"  ");
		}
		LCD_write_english_string(40,line,".");
		LCD_write_english_string(40,line+1,".");
		LCD_write_chinese_string(48,line,12,1,time_a[2]/10,0);
		LCD_write_chinese_string(56,line,12,1,time_a[2]%10,0);
	}
	else if(cho==6)//���
	{
		LCD_write_number(0,0,time_a[5]);
		LCD_write_english_string(24,0,".");
		LCD_write_number(30,0,time_a[4]);
		LCD_write_english_string(42,0,".");
		LCD_write_number(48,0,time_a[3]);
		LCD_write_chinese_string(0,line,12,1,time_a[0]/10,0);
		LCD_write_chinese_string(8,line,12,1,time_a[0]%10,0);		
		LCD_write_english_string(16,line,".");
		LCD_write_english_string(16,line+1,".");
		if(flash)
		{
			LCD_write_number(12,0,time_a[6]);			
		}
		else
		{
			LCD_write_english_string(12,0,"  ");
		}
		LCD_write_english_string(40,line,".");
		LCD_write_english_string(40,line+1,".");
		LCD_write_chinese_string(48,line,12,1,time_a[2]/10,0);
		LCD_write_chinese_string(56,line,12,1,time_a[2]%10,0);
	}
	LCD_write_number(70,0,time_a[7]);
}
void show()
{
	uchar a=8;
//	LCD_write_number(8,1,time_a[0]);

//	LCD_write_number(28,1,time_a[1]);

//	LCD_write_number(48,1,time_a[2]);
	
	LCD_write_number(0,0,time_a[5]);
	LCD_write_number(12,0,time_a[6]);
	LCD_write_english_string(24,0,".");
	LCD_write_number(30,0,time_a[4]);
	LCD_write_english_string(42,0,".");
	LCD_write_number(48,0,time_a[3]);
//	LCD_write_english_string(20,1,":");	
//	LCD_write_english_string(40,1,":");	
	show_time(2);
	LCD_write_number(70,0,time_a[7]);
	//LCD_write_english_string(62,0,"T:");
	//LCD_write_number(74,0,time_a[7]);
	
	/*
	���������X��Y    ����ʾ���ֵ���ʼX��Y���ꣻ
          ch_with �����ֵ���Ŀ���
          num     ����ʾ���ֵĸ�����  
          line    �����ֵ��������е���ʼ����
          row     ��������ʾ���м��
	*/
	//chinese_string(80, 0, "��");
	//LCD_set_XY(10,0);
	//LCD_write_char(time_down[5]);
	//LCD_write_english_string(0,0,time_down);
	//LCD_write_english_string(0,1,time_down); 
}
void key_self()
{
	if(flag<=0)
		return;
	if(!key0)
	{
		Delay10ms(10);
		if(!key0)
		{
			flag--;
			while(!key0&&flag)show_choose(5-flag);
			while(flag)
			{
				inc_dec(5-flag);
				key_self();
			}
		}
	}
	show_choose(5-flag);
}
void key_scan()
{
	unsigned KT=0;
	if(!key0)
	{
		Delay10ms(10);
		if(!key0)
		{
			KT=1;
			while(!key0)show_choose(0);
			while(KT)
			{
				show_choose(0);
				inc_dec(0);
				if(!key0)
				{
					Delay10ms(10);
					if(!key0)
					{
						while(!key0)show_choose(1);
						while(KT)
						{
							show_choose(1);
							inc_dec(1);
							if(!key0)
							{
								Delay10ms(10);
								if(!key0)
								{
									while(!key0)show_choose(2);
									while(KT)
									{
										show_choose(2);
										inc_dec(2);
										if(!key0)
										{
											Delay10ms(10);
											if(!key0)
											{
												while(!key0)show_choose(3);
												while(KT)
												{
													show_choose(3);
													inc_dec(3);
													if(!key0)
													{
														Delay10ms(10);
														if(!key0)
														{
															while(!key0)show_choose(4);
															while(KT)
															{
																show_choose(4);
																inc_dec(4);
																if(!key0)
																{
																	Delay10ms(10);
																	if(!key0)
																	{
																		while(!key0)show_choose(4);
																		SetTimer(time_a[6],time_a[4],time_a[3],time_a[0],time_a[1],0);
																		return;
																	}
																}
															}
															
														}
													}
												}
												
											}
										}
									}
									
								}
							}
							
						}
						
					}
				}
			}
		}
	}
	if(!key3)
	{
		Delay10ms(10);
		if(!key3)
		{
			while(!key3)show();
			bkenable=~bkenable;
			//music_step=~music_step;
		}
	}
}
//void key_scan()
//{
//	char flag=0;
//	unsigned char hhh,mmm,;
//	if(!key0)
//	{
//		Delay10ms(10);
//		if(!key0)
//		{
//			flag=1;
//			while(!key0)show_choose(flag-1);
//			while(flag)
//			{
//				inc_dec(flag-1);
//				if(!key0)
//				{
//					Delay10ms(10);
//					
//				}
//			}
//			
//		}
//		{
//			flag=1;
//			while(!key0)show_choose(1);
//			while(flag)
//			{
//				show_choose(1);
//				if(!key1)
//				{
//					Delay10ms(10);
//					if(!key1)
//					{
//						while(!key1)show_choose(1);
//						time_a[0]++;
//						if(time_a[0]==24)time_a[0]=0;
//						key3=0;
//					}
//				}
//				if(!key2)
//				{
//					Delay10ms(10);
//					if(!key2)
//					{
//						while(!key2)show_choose(1);
//						if(time_a[0]==0)time_a[0]=24;
//						time_a[0]--;
//						key3=1;
//						//if(time_a[0]==24)time_a[0]=0;
//					}
//				}
//				if(!key0)
//				{
//					Delay10ms(10);
//					if(!key0)
//					{
//						while(!key0)show_choose(0);
//						yyy=(char)(time_a[0]+time_a[0]/10*6);
//						while(flag)
//						{
//							show_choose(0);
//							if(!key1)
//							{
//								Delay10ms(10);
//								if(!key1)
//								{
//									while(!key1)show_choose(0);
//									time_a[1]++;
//									if(time_a[1]==60)time_a[0]=0;
//									key3=0;
//								}
//							}
//							if(!key2)
//							{
//								Delay10ms(10);
//								if(!key2)
//								{
//									while(!key2)show_choose(0);
//									if(time_a[1]==0)time_a[0]=60;
//									time_a[1]--;
//									key3=1;
//									//if(time_a[0]==24)time_a[0]=0;
//								}
//							}
//							if(!key0)
//							{
//								Delay10ms(10);
//								if(!key0)
//								{
//									while(!key0)show_choose(0);
//									mmm=(char)(time_a[1]+time_a[1]/10*6);
//									Setclock(yyy,mmm);
//									return;
//								}
//							}
//						}
//					}
//				}
//			}
//		}
//	}
//}
/*********************
flag_c  ���ڵ�����λ 
0-ʱ
1-��
2-�루��Ч��
3-����
4-��
5-��Ч
6-��
**********************/
void inc_dec(unsigned flag_c)
{
	unsigned char change_cc=0;
	if(flag_c==2||flag_c==3)flag_c++;
	else if(flag_c==4)flag_c=6;	
	if(!key1)
	{
		Delay10ms(10);
		if(!key1)
		{
			while(!key1)
				show_choose(flag_c);
			time_a[flag_c]++;
			change_cc=1;//�ӷ�
		}
	}
	if(!key2)
	{
		Delay10ms(10);
		if(!key2)
		{
			while(!key2)
				show_choose(flag_c);
			time_a[flag_c]--;
			change_cc=2;//����
		}
	}
	/*������λ���е���*/
	if(change_cc==1)
	{
		switch(flag_c)
		{
			case 0:
				if(time_a[flag_c]>=24)time_a[flag_c]=0;
			break;
			case 1:
				if(time_a[flag_c]>=60)time_a[flag_c]=0;
			break;
			case 3://����3
				if(time_a[flag_c]>=MAX_DAY+1)time_a[flag_c+1]=0;
			break;
			case 4://��4
				if(time_a[flag_c]>=60)time_a[flag_c+1]=0;
			break;
			case 6://��6
				if(time_a[flag_c]>=99)time_a[flag_c+2]=0;
			break;			
		}
	}
	else if(change_cc==2&&time_a[flag_c]==-1)
	{
		switch(flag_c)
		{
			case 0:
				time_a[flag_c]=23;
			break;
			case 1:
				time_a[flag_c]=59;
			break;
			case 3://����3
				time_a[flag_c]=MAX_DAY;
			break;
			case 4://��4
				time_a[flag_c]=12;
			break;
			case 6://��
				time_a[flag_c]=99;
			break;			
		}
	}
}
void main()
{
	unsigned char i;
	 uchar j=0;
	int temp=11;
	char show_up[16];
	for(i=0;i<10;i++)
	{
//		music[i]=64536-1000*i;
	}
	music_step=0;
	bkenable=1;
	alarm_en=1;
	
	alarm_nn=1;
//                          	SetTime(0x15,0x11,0x04,0x23,0x00,0x55);
	LCD_init(); //��ʼ��Һ��    
	LCD_clear();
	UsartConfiguration();
	InitDS3231();
	while(1)
	{
		Readtime();
		exchange();
		show();
		key_scan();
//		key_self();
//		if(flag<=0)
//		{
//			flag=6;
//			SetTimer(time_a[6],time_a[4],time_a[3],time_a[0],time_a[1],0);
//		}
//		SBUF=key1;
//		while(!TI);		  //�ȴ������������
//		TI=0;			  //���������ɱ�־λ
		//LCD_write_number(48,0,time_a[3]);
		//sprintf(show_up,"%ch:%ch",min,sec);

		//if(!P1^0)flash=!flash;
		//while(!P1^0);
		//Delay10ms(50);		  //��ʱһ���ٷ�
	}
}
/*******************************************************************************
* �� �� ��         :UsartConfiguration()
* ��������		   :���ô���
* ��    ��         : ��
* ��    ��         : ��
*******************************************************************************/

void UsartConfiguration()
{
	SCON=0X50;			//����Ϊ������ʽ1
	TMOD=0X02;			//���ü�����������ʽ2
	PCON=0X80;			//�����ʼӱ�
	TH0=6;
	TL0=6;
	ET0=1;
//	ES=1;						//�򿪽����ж�
	EA=1;						//�����ж�
	TR1=1;					    //�򿪼�����
	TR0=1;
}

/*******************************************************************************
* �� �� ��         : Delay10ms
* ��������		   : ��ʱ��������ʱ10ms
* ��    ��         : ��
* ��    ��         : ��
*******************************************************************************/

void Delay10ms(unsigned int c)   //��� 0us
{
    unsigned char a, b;

	//--c�Ѿ��ڴ��ݹ�����ʱ���Ѿ���ֵ�ˣ�������for����һ��Ͳ��ø�ֵ��--//
    for (;c>0;c--)
	{
		for (b=38;b>0;b--)
		{
			for (a=130;a>0;a--);
		}          
	}       
}
void T0_time() interrupt 1
{

	alarm_en=~alarm_en;
	my_number++;
	if(my_number==2000)
	{
		my_number=0;
		flash=~flash;
		//alarm_en=~alarm_en;
		//key1=~key1;
		//P1^1=~P1^1;
	}
}
